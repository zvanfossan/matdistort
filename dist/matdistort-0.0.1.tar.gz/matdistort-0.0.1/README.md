# matdistort
python package for setting up and analyzing vasp calculations of distorted structures
